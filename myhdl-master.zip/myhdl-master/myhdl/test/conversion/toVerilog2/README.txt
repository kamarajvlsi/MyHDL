Verilog-specific conversion tests
---------------------------------

Requirements:
  * cver, icarus or vlog (default)
  * py.test

See the Makefile - it contains targets per simulator. 
