VHDL-specific conversion tests
------------------------------

Requirements:
  * GHDL or vcom (default)
  * py.test

