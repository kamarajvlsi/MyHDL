Python 3 Support
================

MyHDL supports Python 3.4 and above.
At the moment, core functions, cosimulation and Verilog conversion work perfectly.
However, there are a few unresolved VHDL conversion bugs.

All users are encouraged to try out their existing projects and tests with Python 3 and submit bug reports if anything goes wrong.
