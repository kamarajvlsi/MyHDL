This directory contains the code for the examples from the MyHDL
Cookbook. The Cookbook itself is here:

  http://myhdl.jandecaluwe.com/doku.php/cookbook:intro
