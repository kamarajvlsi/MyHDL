---
name: Usage question
about: Guidance on using MyHDL
title: ''
labels: question
assignees: ''

---

Please refer to our [discourse](http://discourse.myhdl.org/) or <https://gitter.im/myhdl/myhdl>
